import { useEffect, useState } from "react";
import { GoogleLogin } from "@react-oauth/google";

const API = import.meta.env.VITE_API_URL || "http://localhost:5000";

export default function App() {
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem("legal_token") || "");
  const [lawyers, setLawyers] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [message, setMessage] = useState("");
  const [selectedLawyer, setSelectedLawyer] = useState("");
  const [appointmentDate, setAppointmentDate] = useState("");
  const [bookingMessage, setBookingMessage] = useState("");

  const authHeaders = token ? { Authorization: `Bearer ${token}` } : {};

  async function request(path, options = {}) {
    const response = await fetch(`${API}${path}`, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...authHeaders,
        ...(options.headers || {})
      }
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.message || "Something went wrong.");
    return data;
  }

  async function loadLawyers() {
    try { setLawyers(await request("/api/lawyers")); }
    catch (error) { setMessage(error.message); }
  }

  async function loadBookings(currentToken = token) {
    if (!currentToken) return;
    try { setBookings(await request("/api/bookings/my")); }
    catch (error) { setMessage(error.message); }
  }

  useEffect(() => {
    loadLawyers();
    if (token) {
      request("/api/auth/me")
        .then((data) => { setUser(data.user); loadBookings(token); })
        .catch(() => logout());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function saveSession(data) {
    localStorage.setItem("legal_token", data.token);
    setToken(data.token);
    setUser(data.user);
    setMessage(`Welcome, ${data.user.name}!`);
    loadBookings(data.token);
  }

  function logout() {
    localStorage.removeItem("legal_token");
    setToken("");
    setUser(null);
    setBookings([]);
    setMessage("You have logged out.");
  }

  async function handleAuth(event) {
    event.preventDefault();
    setMessage("");
    try {
      const path = mode === "register" ? "/api/auth/register" : "/api/auth/login";
      const data = await request(path, {
        method: "POST",
        body: JSON.stringify(form),
        headers: {}
      });
      saveSession(data);
    } catch (error) { setMessage(error.message); }
  }

  async function handleGoogleSuccess(credentialResponse) {
    try {
      const data = await request("/api/auth/google", {
        method: "POST",
        body: JSON.stringify({ credential: credentialResponse.credential }),
        headers: {}
      });
      saveSession(data);
    } catch (error) { setMessage(error.message); }
  }

  async function handleBooking(event) {
    event.preventDefault();
    if (!token) {
      setMessage("Please log in before requesting a consultation.");
      return;
    }
    try {
      const data = await request("/api/bookings", {
        method: "POST",
        body: JSON.stringify({
          lawyerId: selectedLawyer,
          appointmentDate,
          message: bookingMessage
        })
      });
      setMessage(data.message);
      setAppointmentDate("");
      setBookingMessage("");
      loadBookings();
    } catch (error) { setMessage(error.message); }
  }

  return (
    <div className="app">
      <header className="topbar">
        <a className="brand" href="#home">Legal<span>Connect</span></a>
        <nav><a href="#lawyers">Find a lawyer</a><a href="#booking">Book consultation</a></nav>
        {user ? (
          <div className="account"><span>Hello, {user.name}</span><button className="outline" onClick={logout}>Logout</button></div>
        ) : <a className="nav-login" href="#account">Login</a>}
      </header>

      <main>
        <section className="hero" id="home">
          <div className="hero-copy">
            <p className="eyebrow">LEGAL HELP, MADE SIMPLE</p>
            <h1>Get the right guidance for your <em>next step.</em></h1>
            <p className="hero-text">Explore legal professionals and send a consultation request from one simple place.</p>
            <a className="primary-link" href="#lawyers">Explore lawyers</a>
          </div>
          <div className="hero-card">
            <div className="hero-icon">⚖</div>
            <h3>Clear guidance starts with a conversation.</h3>
            <p>Browse profiles, review areas of practice and request an appointment.</p>
            <div className="hero-line"><span>Simple</span><span>Secure sign-in</span><span>Convenient</span></div>
          </div>
        </section>

        {message && <div className="notice" role="status">{message}</div>}

        <section className="section" id="lawyers">
          <div className="section-heading">
            <div><p className="eyebrow">OUR DIRECTORY</p><h2>Find a legal professional</h2></div>
            <p>Sample profiles can be added to your database.</p>
          </div>
          {lawyers.length === 0 ? (
            <div className="empty">No lawyer profiles yet. Add sample lawyers to MongoDB to display them here.</div>
          ) : (
            <div className="lawyer-grid">
              {lawyers.map((lawyer) => (
                <article className="lawyer-card" key={lawyer._id}>
                  <div className="avatar">{lawyer.name?.charAt(0)?.toUpperCase()}</div>
                  <h3>{lawyer.name}</h3>
                  <p className="specialty">{lawyer.specialization}</p>
                  <p>{lawyer.experienceYears} years experience · {lawyer.city}</p>
                  <strong>₹{lawyer.consultationFee} <small>/ consultation</small></strong>
                  <button onClick={() => { setSelectedLawyer(lawyer._id); document.getElementById("booking").scrollIntoView({ behavior: "smooth" }); }}>
                    Request consultation
                  </button>
                </article>
              ))}
            </div>
          )}
        </section>

        <section className="section two-column" id="account">
          <div className="section-intro">
            <p className="eyebrow">YOUR ACCOUNT</p>
            <h2>{user ? "Your account is ready" : "Sign in to continue"}</h2>
            <p>Create an account or sign in to request consultations and view your booking requests.</p>
            {user && <div className="signed-in"><strong>{user.name}</strong><span>{user.email}</span><span>Account type: {user.role}</span></div>}
          </div>
          {!user && (
            <div className="form-card">
              <div className="tabs">
                <button className={mode === "login" ? "active" : ""} onClick={() => setMode("login")}>Login</button>
                <button className={mode === "register" ? "active" : ""} onClick={() => setMode("register")}>Create account</button>
              </div>
              <form onSubmit={handleAuth}>
                {mode === "register" && <label>Full name<input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Your name" /></label>}
                <label>Email address<input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="name@example.com" /></label>
                <label>Password<input type="password" minLength="8" required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="At least 8 characters" /></label>
                <button className="submit" type="submit">{mode === "register" ? "Create account" : "Login"}</button>
              </form>
              <div className="divider"><span>or</span></div>
              {import.meta.env.VITE_GOOGLE_CLIENT_ID ? (
                <GoogleLogin onSuccess={handleGoogleSuccess} onError={() => setMessage("Google Sign-In failed. Please try again.")} />
              ) : <p className="google-note">Google Sign-In will appear after you add VITE_GOOGLE_CLIENT_ID to frontend/.env.</p>}
            </div>
          )}
        </section>

        <section className="section booking-section" id="booking">
          <div className="section-heading">
            <div><p className="eyebrow">NEXT STEP</p><h2>Request a consultation</h2></div>
            <p>You must be logged in to submit a request.</p>
          </div>
          <form className="booking-form" onSubmit={handleBooking}>
            <label>Choose lawyer
              <select required value={selectedLawyer} onChange={(e) => setSelectedLawyer(e.target.value)}>
                <option value="">Select a lawyer</option>
                {lawyers.map((lawyer) => <option value={lawyer._id} key={lawyer._id}>{lawyer.name} — {lawyer.specialization}</option>)}
              </select>
            </label>
            <label>Appointment date and time<input type="datetime-local" required value={appointmentDate} onChange={(e) => setAppointmentDate(e.target.value)} /></label>
            <label className="wide">Briefly describe what you need help with<textarea rows="3" maxLength="1000" value={bookingMessage} onChange={(e) => setBookingMessage(e.target.value)} placeholder="Share a short, non-confidential summary." /></label>
            <button className="submit" type="submit">Send request</button>
          </form>
          {token && <div className="booking-list"><h3>Your consultation requests</h3>
            {bookings.length === 0 ? <p>No requests yet.</p> : bookings.map((booking) => (
              <div className="booking-row" key={booking._id}>
                <strong>{booking.lawyer?.name || "Lawyer"}</strong>
                <span>{new Date(booking.appointmentDate).toLocaleString()}</span>
                <span className={`status ${booking.status}`}>{booking.status}</span>
              </div>
            ))}
          </div>}
        </section>
      </main>
      <footer><span>LegalConnect</span><p>Demo platform for learning purposes. This website does not provide legal advice.</p></footer>
    </div>
  );
}
